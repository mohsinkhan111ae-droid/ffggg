README - Loading Version
------------------------
Features added:
- Loading overlay with percentage progress (0% -> 100%) when user clicks any Pay Now button.
- After loading completes, the payment flow screen appears (QR / UTR form).
- Price fixed: ₹79
- UPI Deeplink: pa=6005099281@mbk, amount=79, no payee name
- Fake withdrawal notifications still included.
